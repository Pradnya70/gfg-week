import { Component } from "react";




export default class Users extends Component{

    render(){
        return(
            <div>
                {
                    this.props.udata.map((ud) => <user key={ud} userNew={ud} do={this.props.dOne}/>)
                } 
                <button disabled={!this.props.hasData} onClick={this.props.da}>DeleteAll</button>  
            </div>
        )

    }
}    